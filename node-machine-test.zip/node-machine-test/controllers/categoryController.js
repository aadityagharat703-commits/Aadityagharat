const db = require("../config/db");

exports.getCategories = (req, res) => {
    db.query("SELECT * FROM categories", (err, result) => {
        if (err) throw err;
        res.render("category/category", { categories: result });
    });
};

exports.addCategory = (req, res) => {
    const name = req.body.category_name;

    db.query(
        "INSERT INTO categories (category_name) VALUES (?)",
        [name],
        (err) => {
            if (err) throw err;
            res.redirect("/categories");
        }
    );
};


exports.editCategory = (req, res) => {

    const id = req.params.id;

    db.query(
        "SELECT * FROM categories WHERE category_id=?",
        [id],
        (err, result) => {

            if(err) throw err;

            res.render("category/editCategory", {
                category: result[0]
            });

        }
    );
};

exports.updateCategory = (req, res) => {

    const id = req.params.id;
    const name = req.body.category_name;

    db.query(
        "UPDATE categories SET category_name=? WHERE category_id=?",
        [name, id],
        (err) => {

            if(err) throw err;

            res.redirect("/categories");

        }
    );
};

exports.deleteCategory = (req, res) => {
    const id = req.params.id;

    db.query(
        "DELETE FROM categories WHERE category_id=?",
        [id],
        (err) => {
            if (err) throw err;
            res.redirect("/categories");
        }
    );
};