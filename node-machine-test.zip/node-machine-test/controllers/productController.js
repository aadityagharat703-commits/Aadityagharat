const db = require("../config/db");

exports.getProducts = (req, res) => {

    let page = parseInt(req.query.page) || 1;
    let limit = 10;
    let offset = (page - 1) * limit;

    const query = `
    SELECT 
    p.product_id,
    p.product_name,
    c.category_id,
    c.category_name
    FROM products p
    JOIN categories c
    ON p.category_id = c.category_id
    LIMIT ? OFFSET ?
    `;

    db.query(query, [limit, offset], (err, products) => {

        if (err) throw err;

        db.query("SELECT * FROM categories", (err, categories) => {

            res.render("product/product", {
                products,
                categories,
                page
            });

        });

    });

};

exports.addProduct = (req, res) => {

    const { product_name, category_id } = req.body;

    db.query(
        "INSERT INTO products (product_name, category_id) VALUES (?,?)",
        [product_name, category_id],
        () => {
            res.redirect("/products");
        }
    );
};

exports.editProduct = (req, res) => {

    const id = req.params.id;

    db.query(
        "SELECT * FROM products WHERE product_id=?",
        [id],
        (err, product) => {

            db.query("SELECT * FROM categories", (err, categories) => {

                res.render("product/editProduct", {
                    product: product[0],
                    categories
                });

            });

        }
    );
};


exports.updateProduct = (req, res) => {

    const id = req.params.id;
    const { product_name, category_id } = req.body;

    db.query(
        "UPDATE products SET product_name=?, category_id=? WHERE product_id=?",
        [product_name, category_id, id],
        () => {
            res.redirect("/products");
        }
    );
};


exports.deleteProduct = (req, res) => {

    const id = req.params.id;

    db.query(
        "DELETE FROM products WHERE product_id=?",
        [id],
        () => {
            res.redirect("/products");
        }
    );
};