const mysql = require("mysql2");

const db = mysql.createConnection({
    host: "127.0.0.1",
    user: "root",
    password: "",
    database: "machine_test"
});

db.connect((err) => {
    if (err) {
        console.error("DB Connection Failed", err);
    } else {
        console.log("MySQL Connected");
    }
});

module.exports = db;