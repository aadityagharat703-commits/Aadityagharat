const express = require("express");
const bodyParser = require("body-parser");
const methodOverride = require("method-override");

const categoryRoutes = require("./routes/categoryRoutes");
const productRoutes = require("./routes/productRoutes");

const app = express();
const expressLayouts = require("express-ejs-layouts");

app.use(expressLayouts);
app.set("layout", "layout");
app.set("view engine", "ejs");
app.use(express.static("public"));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(methodOverride("_method"));

app.use("/categories", categoryRoutes);
app.use("/products", productRoutes);

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});