const express = require("express");
const router = express.Router();
const controller = require("../controllers/categoryController");

router.get("/", controller.getCategories);
router.post("/add", controller.addCategory);
router.get("/edit/:id", controller.editCategory);
router.post("/update/:id", controller.updateCategory);
router.post("/delete/:id", controller.deleteCategory);
module.exports = router;