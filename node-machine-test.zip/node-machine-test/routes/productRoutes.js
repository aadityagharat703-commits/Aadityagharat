const express = require("express");
const router = express.Router();
const controller = require("../controllers/productController");

router.get("/", controller.getProducts);
router.post("/add", controller.addProduct);
router.get("/edit/:id", controller.editProduct);
router.post("/update/:id", controller.updateProduct);
router.post("/delete/:id", controller.deleteProduct);

module.exports = router;